// main.cpp
#include "Clock.h"

void displayMenu() {
    std::cout << "**************************\n";
    std::cout << "* 1 - Add One Hour       *\n";
    std::cout << "* 2 - Add One Minute     *\n";
    std::cout << "* 3 - Add One Second     *\n";
    std::cout << "* 4 - Exit Program       *\n";
    std::cout << "**************************\n";
}

int main() {
    Clock clock(0, 0, 0); // Initial time can be set here
    int choice;

    while (true) {
        std::cout << "12-Hour Clock: ";
        clock.display12HourFormat();
        std::cout << "24-Hour Clock: ";
        clock.display24HourFormat();
        
        displayMenu();
        std::cin >> choice;

        switch (choice) {
            case 1:
                clock.addHour();
                break;
            case 2:
                clock.addMinute();
                break;
            case 3:
                clock.addSecond();
                break;
            case 4:
                std::cout << "Exiting program.\n";
                return 0;
            default:
                std::cout << "Invalid choice. Please try again.\n";
        }
    }
    return 0;
}
