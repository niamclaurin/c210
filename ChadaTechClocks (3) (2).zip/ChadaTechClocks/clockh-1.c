// File: Clock.h
// Author: Nia McLaurin

#ifndef CLOCK_H
#define CLOCK_H

#include <iostream>
#include <iomanip>
#include <string>

class Clock {
private:
    int hour;
    int minute;
    int second;
public:
    Clock(int h = 0, int m = 0, int s = 0) : hour(h), minute(m), second(s) {}
    void addHour();
    void addMinute();
    void addSecond();
    void display12HourFormat() const;
    void display24HourFormat() const;
};

#endif // CLOCK_H
